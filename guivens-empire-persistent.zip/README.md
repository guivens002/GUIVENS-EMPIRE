# Guivens Empire

## Enstalasyon lokal
1. Enstale Node.js 20 oswa pi resan.
2. Nan dosye pwojè a, kouri `npm install`.
3. Kopye `.env.example` kòm `.env` epi mete yon `JWT_SECRET` long, o aza, prive. Pa janm mete `.env` sou GitHub.
4. Mete `SEED_CODES` ak omwen yon kòd referans inisyal, pa egzanp `GUIWELCOME`.
5. Kouri `npm start` epi louvri `http://localhost:3000`.

## Deplwaye sou Render avèk GitHub
1. Kreye yon repository prive sou GitHub epi telechaje sa ki nan dosye pwojè sa a ladan l. Pa mete `.env`, `data.db`, ni sekrè ladan l.
2. Nan Render, chwazi **New + → Blueprint**, epi konekte repository a. Render ap li `render.yaml`.
3. Konfigirasyon an sèvi ak yon disk pèmanan ki monte nan `/var/data` epi baz done a ap ekri nan `/var/data/data.db`. Disk pèmanan sou Render mande yon plan ki sipòte disk; pa retire disk la si ou bezwen kenbe done yo.
4. Apre premye deplwaman an, ouvri sit la, peze logo a 10 fwa rapid, epi kreye kòd admin ou a. Kenbe kòd la prive.
5. Tcheke nan Render ke `JWT_SECRET`, `DB_FILE=/var/data/data.db`, ak `SEED_CODES` egziste. Pa pataje sekrè yo.

## Panèl administratè
- Sou paj prensipal la, peze logo Guivens Empire 10 fwa nan 2.5 segonn pou louvri `/admin`.
- Premye fwa sèlman, kreye kòd admin solid (omwen 6 karaktè). Sistèm nan pa pèmèt kreye yon lòt apre sa.
- Ou ka ajiste balans, aktive/dezaktive kont, ajiste paramèt, epi wè imaj prèv depo/aktivasyon ki te voye yo.
- Lè ou apwouve yon depo, sistèm nan mete estati a ajou ak kredi balans lan nan yon tranzaksyon baz done pou anpeche doub kredi.

## Done ak sekirite
- SQLite sèvi ak WAL ak `busy_timeout`; sou hosting, mete `DB_FILE` sou disk pèmanan.
- `.env`, `data.db`, ak kopi sovgad pa dwe pibliye nan GitHub.
- Fè sovgad regilye sou baz done a epi teste rekiperasyon an.
- Prèv imaj yo estoke nan baz done a; limite aksè administratè a epi pa kite lòt moun sèvi ak kòd la.
- OCR sou resi pa pwouve poukont li lajan an rive. Verifye peman reyèl yo sou kont NatCash la anvan ou kredite balans oswa aktive kont.
- **Pa sèvi ak jwèt ak lajan reyèl jiskaske rezilta chak jwèt verifye sou sèvè a.** Kounye a, API jwèt la resevwa rezilta nan kliyan an; yon moun teknik ka eseye fo rezilta. Sa mande yon lòt koreksyon sekirite anvan pwodiksyon.
- Fè tès enskripsyon, login, depo, apwobasyon, balans, jwèt ak rekòmansman sèvè anvan ou lanse piblikman.
