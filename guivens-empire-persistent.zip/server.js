try{require('fs').readFileSync('.env','utf8').split('\n').forEach(l=>{const m=l.match(/^\s*([A-Z_]+)\s*=\s*(.*)$/);if(m&&!(m[1] in process.env))process.env[m[1]]=m[2].trim()})}catch(e){}
const fs=require('fs'),path=require('path');
const express=require('express'),Database=require('better-sqlite3'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),multer=require('multer'),crypto=require('crypto'),rateLimit=require('express-rate-limit'),{createWorker}=require('tesseract.js');
const PORT=process.env.PORT||3000,SECRET=process.env.JWT_SECRET;
const DELAY=120000;
if(!SECRET){console.error('Mete JWT_SECRET nan env.');process.exit(1)}
const SEED=(process.env.SEED_CODES||'').split(',').map(s=>s.trim().toUpperCase()).filter(Boolean);
const DB_FILE=process.env.DB_FILE||path.join(__dirname,'data.db');
fs.mkdirSync(path.dirname(path.resolve(DB_FILE)),{recursive:true});
const db=new Database(DB_FILE);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');
db.exec(`create table if not exists users(phone text primary key,name text,pin text,ref_used text,ref_code text unique,active int default 0,created int);
create table if not exists payments(id integer primary key,phone text,transcode text unique,img_hash text unique,created int,activate_at int,done int default 0,proof_blob blob,proof_type text)`);
try{db.exec('alter table payments add column proof_blob blob')}catch(e){}
try{db.exec('alter table payments add column proof_type text')}catch(e){}
try{db.exec('alter table users add column balance real default 0')}catch(e){}
db.exec(`create table if not exists notifs(id integer primary key,phone text,text text,created int,read int default 0);
create table if not exists deposits(id integer primary key,phone text,amount real,transcode text unique,img_hash text unique,created int,status text default 'pending',proof_blob blob,proof_type text);
create table if not exists balance_ledger(id integer primary key,phone text,delta real,balance_after real,reason text,ref text,created int);`);
// Migrasyon san danje pou baz done ki te deja egziste.
try{db.exec('alter table deposits add column proof_blob blob')}catch(e){}
try{db.exec('alter table deposits add column proof_type text')}catch(e){}
const ledger=(phone,delta,balance,reason,ref='')=>db.prepare('insert into balance_ledger(phone,delta,balance_after,reason,ref,created) values(?,?,?,?,?,?)').run(phone,delta,balance,reason,String(ref),Date.now());
const note=(p,t)=>db.prepare('insert into notifs(phone,text,created) values(?,?,?)').run(p,t,Date.now());
const DEF=JSON.parse(fs.readFileSync(path.join(__dirname,'defaults.json'),'utf8'));
db.exec('create table if not exists settings(k text primary key,v text)');
function getCfg(){const r=db.prepare("select v from settings where k='cfg'").get();let o={};try{o=r?JSON.parse(r.v):{}}catch(e){}return{...DEF,...o,legal:{...DEF.legal,...(o.legal||{})},games:{...DEF.games,...(o.games||{})}}}
const app=express();app.set('trust proxy',1);app.use(express.json({limit:'10kb'}));
const up=multer({storage:multer.memoryStorage(),limits:{fileSize:8e6},fileFilter:(q,f,cb)=>cb(null,/^image\/(png|jpe?g|webp)$/.test(f.mimetype))});
const wrap=f=>(q,s)=>f(q,s).catch(e=>{console.error(e);s.status(500).json({error:'Erè sèvè. Eseye ankò.'})});
const bad=(s,m,c=400)=>s.status(c).json({error:m});
const lim=rateLimit({windowMs:15*60*1000,max:20,standardHeaders:true,message:{error:'Twòp tantativ. Eseye ankò nan 15 minit.'}});
function auth(q,s,n){try{q.phone=jwt.verify((q.headers.authorization||'').slice(7),SECRET).p;n()}catch(e){bad(s,'Rekonekte w.',401)}}
function newCode(name){for(;;){const c='GUI'+(name.replace(/[^A-Za-z]/g,'').slice(0,3).toUpperCase()||'EMP')+(1000+crypto.randomInt(9000));if(!db.prepare('select 1 from users where ref_code=?').get(c))return c}}
function activate(phone){const u=db.prepare('select * from users where phone=?').get(phone);if(u&&!u.active){const c=newCode(u.name);db.prepare('update users set active=1,ref_code=? where phone=?').run(c,phone);note(phone,'Kont ou aktive! Kòd referans ou: '+c)}}
// Aktivasyon otomatik apre 2 minit
setInterval(()=>{for(const p of db.prepare('select * from payments where done=0 and activate_at<=?').all(Date.now())){activate(p.phone);db.prepare('update payments set done=1 where id=?').run(p.id)}},5000);
// OCR (yon sèl worker, demann yo fèt youn apre lòt)
let W,Q=Promise.resolve();
const ocr=buf=>Q=Q.catch(()=>{}).then(async()=>{W=W||await createWorker('eng');return(await W.recognize(buf)).data.text});

app.post('/api/register',lim,wrap(async(q,s)=>{
 const{name='',phone='',pin='',ref=''}=q.body,r=String(ref).trim().toUpperCase();
 if(String(name).trim().length<3)return bad(s,'Antre non konplè ou.');
 if(!/^\d{8}$/.test(phone))return bad(s,'Nimewo telefòn nan dwe gen 8 chif san 509.');
 if(!/^\d{4}$/.test(pin))return bad(s,'PIN nan dwe gen 4 chif.');
 if(!r)return bad(s,'Kòd referans obligatwa.');
 if(!SEED.includes(r)&&!db.prepare('select 1 from users where ref_code=? and active=1').get(r))return bad(s,'Kòd referans lan pa bon.');
 if(db.prepare('select 1 from users where phone=?').get(phone))return bad(s,'Nimewo sa a gen yon kont deja.');
 db.prepare('insert into users(phone,name,pin,ref_used,created) values(?,?,?,?,?)').run(phone,String(name).trim().slice(0,60),await bcrypt.hash(pin,10),r,Date.now());
 note(phone,'Byenveni nan Guivens Empire! Kont ou kreye.');
 s.json({ok:true})}));

app.post('/api/login',lim,wrap(async(q,s)=>{
 const u=db.prepare('select * from users where phone=?').get(String(q.body.phone||''));
 if(!u||!(await bcrypt.compare(String(q.body.pin||''),u.pin)))return bad(s,'Nimewo oswa PIN pa kòrèk.',401);
 note(u.phone,'Ou konekte nan kont ou.');s.json({token:jwt.sign({p:u.phone},SECRET,{expiresIn:'30d'})})}));

app.get('/api/me',auth,wrap(async(q,s)=>{
 const u=db.prepare('select * from users where phone=?').get(q.phone);if(!u)return bad(s,'Kont pa egziste.',401);
 const p=db.prepare('select activate_at from payments where phone=? and done=0').get(q.phone);
 s.json({name:u.name,phone:u.phone,active:!!u.active,balance:u.balance||0,ref_code:u.ref_code,ref_used:u.ref_used,pending:p?Math.max(1,Math.ceil((p.activate_at-Date.now())/1000)):0})}));

app.post('/api/activate',auth,up.single('proof'),wrap(async(q,s)=>{
 const u=db.prepare('select * from users where phone=?').get(q.phone);
 if(u.active)return bad(s,'Kont ou aktive deja.');
 if(db.prepare('select 1 from payments where phone=? and done=0').get(q.phone))return bad(s,'Ou gen yon peman ki an atant deja.');
 const tc=String(q.body.transcode||'').toUpperCase().replace(/\s/g,'');
 if(tc.length<4)return bad(s,'Antre transcode a.');
 if(!q.file)return bad(s,'Chwazi yon kapti ekran (PNG, JPG oswa WebP).');
 const raw=await ocr(q.file.buffer),T=raw.toUpperCase(),digits=T.replace(/\D/g,''),flat=T.replace(/\s/g,'');
 const why=[];
 if(!new RegExp('(^|\\D)'+getCfg().amount+'\\s*HTG').test(T))why.push('Montan an pa '+getCfg().amount+' HTG.');
 if(!digits.includes(getCfg().natcash))why.push('Nimewo ki resevwa lajan an pa bon.');
 if(!new RegExp('\\d{1,2}\\/\\d{1,2}\\/'+new Date().getFullYear()).test(T.replace(/\s/g,'')))why.push('Dat la manke oswa pa bon.');
 if(!flat.includes(tc))why.push('Transcode ki sou resi a pa menm ak sa w antre a.');
 if(why.length)return bad(s,'Prèv la pa bon. '+why.join(' '),422);
 const h=crypto.createHash('sha256').update(q.file.buffer).digest('hex');
 if(db.prepare('select 1 from deposits where transcode=? or img_hash=?').get(tc,h))return bad(s,'Transcode oswa imaj sa a deja itilize.');
 try{db.prepare('insert into payments(phone,transcode,img_hash,created,activate_at,proof_blob,proof_type) values(?,?,?,?,?,?,?)').run(q.phone,tc,h,Date.now(),Date.now()+DELAY,q.file.buffer,q.file.mimetype)}
 catch(e){return bad(s,'Transcode oswa imaj sa a deja itilize.')}
 note(q.phone,'Prèv peman '+getCfg().amount+' HTG resevwa. Kont ou ap aktive nan 2 minit.');s.json({ok:true,seconds:DELAY/1000})}));

app.post('/api/pin',lim,auth,wrap(async(q,s)=>{const u=db.prepare('select * from users where phone=?').get(q.phone);
 if(!/^\d{4}$/.test(String(q.body.pin||'')))return bad(s,'Nouvo PIN nan dwe gen 4 chif.');
 if(!(await bcrypt.compare(String(q.body.old||''),u.pin)))return bad(s,'PIN aktyèl la pa bon.',401);
 db.prepare('update users set pin=? where phone=?').run(await bcrypt.hash(q.body.pin,10),q.phone);note(q.phone,'PIN ou chanje.');s.json({ok:true})}));

const NAMES=['Jeyografi & Mond','Kilti Jeneral','Sinema & Seri','Enfòmatik & Tech','Espò & Foutbòl','Istwa & Ayiti','Syans & Lanati','Lojik & Matematik','Bib & Spirityalite','Anglè & Lang'];
app.get('/api/notifs',auth,wrap(async(q,s)=>s.json({list:db.prepare('select text,created t,read from notifs where phone=? order by id desc limit 100').all(q.phone).map(r=>({text:r.text,t:r.t,read:!!r.read}))})));
app.post('/api/notifs/read',auth,wrap(async(q,s)=>{db.prepare('update notifs set read=1 where phone=?').run(q.phone);s.json({ok:true})}));
app.post('/api/quiz',auth,wrap(async(q,s)=>{
 const u=db.prepare('select active from users where phone=?').get(q.phone),c=+q.body.cat,a=+q.body.score,n=+q.body.total;
 if(!u||!u.active)return bad(s,'Aktive kont ou anvan.',403);
 if(!(c>=0&&c<NAMES.length&&n>0&&n<=10&&a>=0&&a<=n))return bad(s,'Done pa bon.');
 note(q.phone,'Kwiz '+NAMES[c]+': '+a+'/'+n+' bon repons.');s.json({ok:true})}));
app.post('/api/deposit',auth,up.single('proof'),wrap(async(q,s)=>{
 const amt=Math.floor(Number(q.body.amount)),tc=String(q.body.transcode||'').toUpperCase().replace(/\s/g,'');
 if(!(amt>=1&&amt<=1000000))return bad(s,'Antre yon montan valid.');
 if(tc.length<4)return bad(s,'Antre transcode a.');
 if(!q.file)return bad(s,'Chwazi yon kapti ekran (PNG, JPG oswa WebP).');
 const T=(await ocr(q.file.buffer)).toUpperCase(),flat=T.replace(/\s/g,''),why=[];
 if(!new RegExp('(^|\\D)'+amt+'(\\.0+)?\\s*HTG').test(T))why.push('Montan an pa koresponn ak '+amt+' HTG.');
 if(!T.replace(/\D/g,'').includes(getCfg().natcash))why.push('Nimewo ki resevwa lajan an pa bon.');
 if(!new RegExp('\\d{1,2}\\/\\d{1,2}\\/'+new Date().getFullYear()).test(flat))why.push('Dat la manke oswa pa bon.');
 if(!flat.includes(tc))why.push('Transcode ki sou resi a pa menm ak sa w antre a.');
 if(why.length)return bad(s,'Prèv la pa bon. '+why.join(' '),422);
 const proofHash=crypto.createHash('sha256').update(q.file.buffer).digest('hex');
 if(db.prepare('select 1 from payments where transcode=? or img_hash=?').get(tc,proofHash))return bad(s,'Transcode oswa imaj sa a deja itilize.');
 try{db.prepare('insert into deposits(phone,amount,transcode,img_hash,created,proof_blob,proof_type) values(?,?,?,?,?,?,?)').run(q.phone,amt,tc,proofHash,Date.now(),q.file.buffer,q.file.mimetype)}
 catch(e){return bad(s,'Transcode oswa imaj sa a deja itilize.')}
 note(q.phone,'Depo '+amt+' HTG resevwa. Li an atant verifikasyon.');s.json({ok:true})}));
db.exec('create table if not exists games(id integer primary key,phone text,game text,bet real,win real,created int,done int default 0)');
app.post('/api/game/start',auth,wrap(async(q,s)=>{
 const C=getCfg(),g=String(q.body.game||''),c=C.games[g],bet=Math.floor(Number(q.body.bet));if(!c)return bad(s,'Jwèt sa a pa egziste.');
 if(!(bet>=c.min&&bet<=c.max))return bad(s,'Miz la dwe ant '+c.min+' ak '+c.max+' HTG.');
 const u=db.prepare('select active from users where phone=?').get(q.phone);if(!u||!u.active)return bad(s,'Aktive kont ou anvan.',403);
 db.prepare('update games set done=1 where phone=? and done=0').run(q.phone);
 const r=db.prepare('update users set balance=balance-? where phone=? and coalesce(balance,0)>=?').run(bet,q.phone,bet);
 if(!r.changes)return bad(s,'Balans ou pa sifi pou miz sa a. Fè yon depo anvan.');
 const afterBet=db.prepare('select coalesce(balance,0) balance from users where phone=?').get(q.phone);ledger(q.phone,-bet,afterBet.balance,'game_bet',g);
 const win=bet*C.gameMult,i=db.prepare('insert into games(phone,game,bet,win,created) values(?,?,?,?,?)').run(q.phone,g,bet,win,Date.now());
 s.json({id:i.lastInsertRowid,bet,win})}));
app.post('/api/game/end',auth,wrap(async(q,s)=>{
 const result=db.transaction(()=>{const g=db.prepare('select * from games where id=? and phone=? and done=0').get(+q.body.id,q.phone);if(!g)return null;
 db.prepare('update games set done=1 where id=? and done=0').run(g.id);const res=String(q.body.result);let paid=0;
 // Remak: rezilta kliyan an voye a pa yon prèv endepandan. Pa sèvi ak jwèt sa yo ak lajan reyèl jiskaske rezilta yo verifye sou sèvè a.
 if(res==='win'&&Date.now()-g.created>=20000)paid=g.win;else if(res==='draw')paid=g.bet;
 if(paid){const u=db.prepare('select coalesce(balance,0) balance from users where phone=?').get(q.phone),nb=u.balance+paid;db.prepare('update users set balance=? where phone=?').run(nb,q.phone);ledger(q.phone,paid,nb,res==='win'?'game_payout':'game_refund',g.id)}
 note(q.phone,g.game+': '+(paid&&res==='win'?'ou genyen +'+paid+' HTG':res==='draw'?'egalite, miz remèt':'ou pèdi '+g.bet+' HTG'));return {ok:true,paid}})();if(!result)return bad(s,'Pati a fini deja.',409);s.json(result)}));
// Kwiz: kesyon pa janm repete pou menm kont lan
const BANK=JSON.parse(fs.readFileSync(path.join(__dirname,'questions.json'),'utf8'));
db.exec('create table if not exists quiz_seen(phone text,qid text,primary key(phone,qid));create table if not exists quiz_sess(id integer primary key,phone text,ans int,created int,done int default 0)');
function genMath(){const t=crypto.randomInt(3);let q,a;
 if(t===0){const x=12+crypto.randomInt(38),y=3+crypto.randomInt(17);q='Konbyen fè '+x+' × '+y+' ?';a=x*y}
 else if(t===1){const p=[5,10,15,20,25,30,40,60][crypto.randomInt(8)],n=(4+crypto.randomInt(46))*20;q='Konbyen fè '+p+'% de '+n+' ?';a=p*n/100}
 else{const st=1+crypto.randomInt(9),df=2+crypto.randomInt(9);q='Ki nimewo ki vini apre nan seri a: '+[0,1,2,3].map(i=>st+df*i).join(', ')+' ?';a=st+df*4}
 const o=new Set([a]);while(o.size<4){const v=a+crypto.randomInt(21)-10;if(v>0)o.add(v)}
 const l=[...o].sort(()=>crypto.randomInt(2)-.5);return[q,l.map(String),l.indexOf(a)]}
app.post('/api/quiz/start',auth,wrap(async(q,s)=>{
 const c=+q.body.cat,u=db.prepare('select active from users where phone=?').get(q.phone);
 if(!u||!u.active)return bad(s,'Aktive kont ou anvan.',403);if(!(c>=0&&c<BANK.length))return bad(s,'Kategori pa bon.');
 const seen=new Set(db.prepare('select qid from quiz_seen where phone=?').all(q.phone).map(r=>r.qid));
 let pool=BANK[c].map((x,i)=>[c+':'+i,x]).filter(([id])=>!seen.has(id));
 pool=pool.map(v=>[crypto.randomInt(1e9),v]).sort((a,b)=>a[0]-b[0]).map(v=>v[1]).slice(0,10);
 if(c===7)while(pool.length<10){const g=genMath();pool.push(['g:'+crypto.randomUUID(),g])}
 const list=[];
 for(const[id,x]of pool){db.prepare('insert or ignore into quiz_seen(phone,qid) values(?,?)').run(q.phone,id);
  const r=db.prepare('insert into quiz_sess(phone,ans,created) values(?,?,?)').run(q.phone,x[2],Date.now());list.push({sid:r.lastInsertRowid,q:x[0],o:x[1]})}
 s.json({list})}));
app.post('/api/quiz/answer',auth,wrap(async(q,s)=>{
 const r=db.prepare('select * from quiz_sess where id=? and phone=? and done=0').get(+q.body.sid,q.phone);if(!r)return bad(s,'Kesyon sa a fini deja.');
 const claimed=db.prepare('update quiz_sess set done=1 where id=? and done=0').run(r.id);if(!claimed.changes)return bad(s,'Kesyon sa a fini deja.',409);const ok=+q.body.choice===r.ans&&Date.now()-r.created<=40000,C=getCfg();
 if(ok){const cur=db.prepare('select coalesce(balance,0) balance from users where phone=?').get(q.phone);const nb=cur.balance+C.quizReward;db.prepare('update users set balance=? where phone=?').run(nb,q.phone);ledger(q.phone,C.quizReward,nb,'quiz_correct',r.id);
  const u=db.prepare('select ref_used from users where phone=?').get(q.phone);
  if(u&&u.ref_used&&C.refBonus)(()=>{const refUser=db.prepare('select phone,coalesce(balance,0) balance from users where ref_code=? and active=1').get(u.ref_used);if(refUser){const b=refUser.balance+C.refBonus;db.prepare('update users set balance=? where phone=?').run(b,refUser.phone);ledger(refUser.phone,C.refBonus,b,'referral_bonus',r.id)}})()}
 s.json({correct:ok,right:r.ans,reward:ok?C.quizReward:0})}));
// DG: wè ak apwouve depo yo
// Kòd admin: kreye yon sèl fwa, apre sa pèsonn pa ka kreye yon lòt
const AH=()=>{const r=db.prepare("select v from settings where k='admin'").get();return r&&r.v};
const hk=(k,salt)=>crypto.scryptSync(k,salt,32).toString('hex'),atok=()=>jwt.sign({adm:1},SECRET,{expiresIn:'12h'});
app.get('/api/admin/status',(q,s)=>s.json({setup:!!AH()}));
app.post('/api/admin/setup',lim,(q,s)=>{
 if(AH())return bad(s,'Kòd admin lan deja kreye. Pèsonn pa ka kreye yon lòt.',403);
 const k=String(q.body.key||'');if(k.length<6||k.length>64)return bad(s,'Kòd la dwe gen ant 6 ak 64 karaktè.');
 const salt=crypto.randomBytes(16).toString('hex');
 const r=db.prepare("insert or ignore into settings(k,v) values('admin',?)").run(salt+':'+hk(k,salt));
 if(!r.changes)return bad(s,'Kòd admin lan deja kreye.',403);s.json({token:atok()})});
app.post('/api/admin/login',lim,(q,s)=>{const v=AH();if(!v)return bad(s,'Kreye kòd admin lan anvan.',409);
 const[salt,h]=v.split(':');if(!crypto.timingSafeEqual(Buffer.from(hk(String(q.body.key||''),salt)),Buffer.from(h)))return bad(s,'Kòd la pa bon.',403);s.json({token:atok()})});
const isAdm=q=>{try{return !!jwt.verify(String(q.headers['x-admin-key']||''),SECRET).adm}catch(e){return false}};
app.get('/api/admin/deposits',(q,s)=>isAdm(q)?s.json(db.prepare("select id,phone,amount,transcode,created,case when proof_blob is null then 0 else 1 end hasProof from deposits where status='pending' order by created asc").all()):bad(s,'Non otorize.',403));
app.get('/api/admin/deposit-proof/:id',(q,s)=>{if(!isAdm(q))return bad(s,'Non otorize.',403);const d=db.prepare('select proof_blob,proof_type from deposits where id=?').get(+q.params.id);if(!d||!d.proof_blob)return bad(s,'Prèv la pa disponib.',404);s.set('Content-Type',d.proof_type||'application/octet-stream');s.set('Cache-Control','no-store');s.send(d.proof_blob)});
app.post('/api/admin/deposit',(q,s)=>{if(!isAdm(q))return bad(s,'Non otorize.',403);
 const id=+q.body.id,approve=!!q.body.approve;
 const result=db.transaction(()=>{const d=db.prepare("select * from deposits where id=? and status='pending'").get(id);if(!d)return null;
 if(approve){const u=db.prepare('select coalesce(balance,0) balance from users where phone=?').get(d.phone);if(!u)return null;const nb=u.balance+d.amount;db.prepare('update users set balance=? where phone=?').run(nb,d.phone);ledger(d.phone,d.amount,nb,'deposit_approved',d.transcode);db.prepare("update deposits set status='ok' where id=? and status='pending'").run(d.id);note(d.phone,'Depo '+d.amount+' HTG konfime. Balans ou ajou.')}
 else{db.prepare("update deposits set status='no' where id=? and status='pending'").run(d.id);note(d.phone,'Depo '+d.amount+' HTG refize. Kontakte sipò.')}
 return true})();if(!result)return bad(s,'Depo a deja trete oswa kliyan an pa jwenn.',409);s.json({ok:true})});
// DG: aktive yon kont manyèlman (si OCR pa li byen)
app.post('/api/admin/activate',(q,s)=>{
 if(!isAdm(q))return bad(s,'Non otorize.',403);
 activate(String(q.body.phone||''));s.json({ok:true})});
app.post('/api/admin/deactivate',(q,s)=>{
 if(!isAdm(q))return bad(s,'Non otorize.',403);
 const ph=String(q.body.phone||'');const u=db.prepare('select phone from users where phone=?').get(ph);if(!u)return bad(s,'Kliyan pa jwenn.',404);
 db.prepare('update users set active=0 where phone=?').run(ph);note(ph,'Kont ou mete an atant pou verifikasyon pa administratè a.');s.json({ok:true})});

app.get('/api/config',(q,s)=>s.json(getCfg()));
const admLim=rateLimit({windowMs:15*60*1000,max:120,standardHeaders:true,message:{error:'Twòp tantativ.'}});
const adm=(q,s,n)=>isAdm(q)?n():bad(s,'Non otorize.',403);
const cnt=(sql)=>db.prepare(sql).get().n;
app.get('/api/admin/stats',admLim,adm,(q,s)=>s.json({users:cnt('select count(*) n from users'),active:cnt('select count(*) n from users where active=1'),pendingDeposits:cnt("select count(*) n from deposits where status='pending'"),pendingPayments:cnt('select count(*) n from payments where done=0'),balance:cnt('select coalesce(sum(balance),0) n from users')}));
app.get('/api/admin/users',admLim,adm,(q,s)=>s.json(db.prepare('select phone,name,active,coalesce(balance,0) balance,ref_code,ref_used,created from users order by created desc limit 1000').all()));
app.get('/api/admin/payments',admLim,adm,(q,s)=>s.json(db.prepare('select id,phone,transcode,created,activate_at,done,case when proof_blob is null then 0 else 1 end hasProof from payments order by id desc limit 300').all()));
app.get('/api/admin/payment-proof/:id',(q,s)=>{if(!isAdm(q))return bad(s,'Non otorize.',403);const d=db.prepare('select proof_blob,proof_type from payments where id=?').get(+q.params.id);if(!d||!d.proof_blob)return bad(s,'Prèv la pa disponib.',404);s.set('Content-Type',d.proof_type||'application/octet-stream');s.set('Cache-Control','no-store');s.send(d.proof_blob)});
app.get('/api/admin/config',admLim,adm,(q,s)=>s.json(getCfg()));
app.post('/api/admin/config',admLim,adm,(q,s)=>{
 const b=q.body||{},o={},str=(v,n)=>typeof v==='string'&&v.length<=n;
 const nc=String(b.natcash||'').replace(/\s/g,'');if(!/^\d{8}$/.test(nc))return bad(s,'NatCash: 8 chif san 509.');o.natcash=nc;
 const a=Math.floor(Number(b.amount));if(!(a>=1&&a<=1000000))return bad(s,'Montan aktivasyon an pa bon.');o.amount=a;
 if(!str(b.email,120)||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b.email.trim()))return bad(s,'Imèl la pa bon.');o.email=b.email.trim();
 const ph=String(b.phone||'').replace(/\D/g,'');if(ph.length<8||ph.length>15)return bad(s,'Telefòn lan pa bon.');o.phone=ph;
 if(!str(b.wa,300)||!/^https:\/\//.test(b.wa.trim()))return bad(s,'Lyen WhatsApp la dwe kòmanse ak https://');o.wa=b.wa.trim();
 if(!str(b.hours,100))return bad(s,'Orè a two long.');o.hours=b.hours;
 if(!Array.isArray(b.faq)||b.faq.length>20||b.faq.some(f=>!f||!str(f.q,200)||!str(f.a,800)))return bad(s,'Kesyon yo pa bon.');o.faq=b.faq.map(f=>({q:f.q,a:f.a}));
 const L=b.legal||{};if(!['priv','terms','refund'].every(k=>str(L[k],8000)))return bad(s,'Tèks legal yo pa bon.');o.legal={priv:L.priv,terms:L.terms,refund:L.refund};
 const G=b.games||{};o.games={};for(const k of Object.keys(DEF.games)){const x=G[k]||{},mn=Math.floor(Number(x.min)),mx=Math.floor(Number(x.max));if(!(mn>=1&&mx>=mn&&mx<=1000000))return bad(s,'Miz min/max '+k+' pa bon.');o.games[k]={min:mn,max:mx}}
 const gm=Number(b.gameMult);if(!(gm>=1&&gm<=10))return bad(s,'Miltiplikatè jwèt la pa bon.');o.gameMult=gm;
 const qr=Math.floor(Number(b.quizReward)),rb=Math.floor(Number(b.refBonus));if(!(qr>=0&&qr<=10000&&rb>=0&&rb<=10000))return bad(s,'Gen kwiz/parenaj pa bon.');o.quizReward=qr;o.refBonus=rb
 db.prepare("insert into settings(k,v) values('cfg',?) on conflict(k) do update set v=excluded.v").run(JSON.stringify(o));s.json({ok:true})});
app.post('/api/admin/balance',admLim,adm,(q,s)=>{const ph=String(q.body.phone||''),amt=Number(q.body.amount),mode=q.body.mode==='set'?'set':'add';
 const u=db.prepare('select coalesce(balance,0) b from users where phone=?').get(ph);if(!u)return bad(s,'Kliyan pa jwenn.',404);
 if(!Number.isFinite(amt)||Math.abs(amt)>1e7)return bad(s,'Montan pa bon.');
 const nb=mode==='set'?amt:u.b+amt;if(nb<0)return bad(s,'Balans pa ka negatif.');
 db.transaction(()=>{db.prepare('update users set balance=? where phone=?').run(nb,ph);ledger(ph,nb-u.b,nb,mode==='set'?'admin_set_balance':'admin_adjust_balance','admin')})();
 note(ph,mode==='set'?'Administratè a mete balans ou a '+nb+' HTG.':(amt>=0?'+':'')+amt+' HTG sou balans ou (administratè).');s.json({ok:true,balance:nb})});
app.get('/admin',(q,s)=>s.sendFile(path.join(__dirname,'public','admin.html'),{headers:{'Cache-Control':'no-cache'}}));
const ver=()=>{let t=0;for(const f of['index.html','games.js','live.js','admin.html'])try{t=Math.max(t,fs.statSync(path.join(__dirname,'public',f)).mtimeMs)}catch(e){}return crypto.createHash('md5').update(t+JSON.stringify(getCfg())).digest('hex').slice(0,10)};
app.get('/api/version',(q,s)=>{s.set('Cache-Control','no-store');s.json({v:ver()})});
app.use(express.static(path.join(__dirname,'public'),{setHeaders:(r,p)=>{if(/\.(html|js)$/.test(p))r.setHeader('Cache-Control','no-cache')}}));
app.listen(PORT,()=>console.log('Guivens Empire sou pò '+PORT));
