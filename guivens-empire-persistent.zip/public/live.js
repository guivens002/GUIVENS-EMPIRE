(()=>{
let n=0,tm;
document.addEventListener("click",e=>{const i=e.target.closest&&e.target.closest("img");if(!i||!i.closest(".brand,.top"))return;
 clearTimeout(tm);tm=setTimeout(()=>n=0,4000);if(++n>=10){n=0;location.href="/admin"}});
let V=null;
async function chk(){try{const j=await(await fetch("/api/version",{cache:"no-store"})).json();
 if(V&&j.v!==V){if(document.querySelector(".gmo"))return;V=j.v;return location.reload()}V=j.v}catch(e){}}
chk();setInterval(chk,45000);document.addEventListener("visibilitychange",()=>{if(!document.hidden)chk()});
(async()=>{if(!TOKEN)return;try{const m=await api("me");enter({n:m.name,c:m.ref_used,act:m.active,code:m.ref_code,balance:m.balance},m.phone)}
 catch(e){TOKEN="";try{localStorage.removeItem("gt")}catch(x){}}})();
})();
