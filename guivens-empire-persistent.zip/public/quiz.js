(()=>{
const $=id=>document.getElementById(id);let S=null,T=null;const old=startQuiz;
const css=document.createElement("style");css.textContent=".qt{font-weight:700;color:#0050ff;margin:0 0 10px;font-size:18px}.qt.l{color:#d9141f}.qo.ok{background:#c8f7d4!important;color:#0a5a2a!important}.qo.no{background:#ffd2cc!important;color:#7a1608!important}.qcoin{position:fixed;left:50%;top:42%;z-index:2000;font:700 30px Poppins,sans-serif;color:#0a7a45;pointer-events:none;animation:qc 1.4s ease-out forwards}@keyframes qc{0%{transform:translate(-50%,0) scale(.6);opacity:0}20%{opacity:1;transform:translate(-50%,-20px) scale(1.2)}100%{transform:translate(-50%,-140px) scale(1);opacity:0}}.qcn{position:fixed;top:-40px;font-size:26px;z-index:2000;pointer-events:none;animation:qf 1.3s ease-in forwards}@keyframes qf{to{transform:translateY(115vh) rotate(360deg)}}";document.head.append(css);
function coins(n){const m=document.createElement("div");m.className="qcoin";m.textContent="💰 +"+n+" HTG";document.body.append(m);setTimeout(()=>m.remove(),1500);
 for(let i=0;i<10;i++){const c=document.createElement("span");c.className="qcn";c.textContent="🪙";c.style.left=(5+Math.random()*90)+"%";c.style.animationDelay=(Math.random()*.4)+"s";document.body.append(c);setTimeout(()=>c.remove(),1900)}}
function back(){const o=$("qzo");o.textContent="";const b=document.createElement("button");b.className="org";b.textContent="Retounen nan kategori yo";b.onclick=()=>tab("quiz");o.appendChild(b)}
startQuiz=async function(c){if(!SRV)return old(c);clearInterval(T);
 $("qzc").textContent=CATS[c][0];$("qzp").textContent="";$("qzq").textContent="N ap chaje kesyon yo...";$("qzo").textContent="";tab("qz");
 try{const r=await api("quiz/start",{body:{cat:c}});
  if(!r.list.length){$("qzq").textContent="Ou deja reponn tout kesyon ki nan kategori sa a. Nouvo kesyon ap ajoute byento.";return back()}
  S={c,list:r.list,i:0,ok:0,gain:0};next()}catch(e){$("qzq").textContent=e.message;back()}};
function next(){clearInterval(T);if(S.i>=S.list.length)return fin();const q=S.list[S.i],o=$("qzo");
 $("qzp").textContent="Kesyon "+(S.i+1)+"/"+S.list.length;$("qzq").textContent=q.q;o.textContent="";
 const tm=document.createElement("div");tm.className="qt";o.appendChild(tm);let left=30,lock=false;
 const bs=q.o.map((t,i)=>{const b=document.createElement("button");b.className="mi qo";b.textContent=t;b.onclick=()=>ans(i);o.appendChild(b);return b});
 const tick=()=>{tm.textContent="⏱ "+left+" s";tm.classList.toggle("l",left<=10)};tick();
 T=setInterval(()=>{left--;tick();if(left<=0)ans(-1)},1000);
 async function ans(i){if(lock)return;lock=true;clearInterval(T);let r={correct:false,right:-1};
  try{r=await api("quiz/answer",{body:{sid:q.sid,choice:i}})}catch(e){toast(e.message)}
  if(r.right>=0)bs[r.right].classList.add("ok");if(i>=0&&!r.correct)bs[i].classList.add("no");
  if(r.correct){S.ok++;S.gain+=r.reward;coins(r.reward)}else if(i<0)tm.textContent="Tan fini!";
  pull();setTimeout(()=>{S.i++;next()},r.correct?1400:1200)}}
function fin(){$("qzp").textContent="Rezilta";$("qzq").textContent="Ou fè "+S.ok+"/"+S.list.length+" bon repons"+(S.gain?" · +"+S.gain+" HTG":"")+".";
 api("quiz",{body:{cat:S.c,score:S.ok,total:S.list.length}}).then(pull).catch(()=>{});back()}
})();
