(()=>{
const $=id=>document.getElementById(id),E=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e},R=n=>Math.floor(Math.random()*n),sh=a=>{for(let i=a.length-1;i>0;i--){const j=R(i+1);[a[i],a[j]]=[a[j],a[i]]}return a};
const css=E("style");css.textContent=`
.gmo{position:fixed;inset:0;z-index:999;background:radial-gradient(ellipse at 50% 30%,#1e6b3a,#0a2f18 80%);color:#fff;display:flex;flex-direction:column;padding:env(safe-area-inset-top,0) 0 env(safe-area-inset-bottom,0);font-family:Poppins,system-ui,sans-serif}
.gmo header{display:flex;align-items:center;gap:12px;padding:12px 14px}.gbk{border:0;border-radius:50%;width:40px;height:40px;background:rgba(255,255,255,.15);color:#fff;font-size:20px}
.gt b{display:block;font-size:20px}.gt small{color:#f5c542}.gstat{text-align:center;margin:0 14px;padding:10px 14px;color:#ffd35a;font-weight:600;min-height:44px;background:rgba(245,197,66,.1);border:1px solid rgba(245,197,66,.25);border-radius:14px}
.mcard{display:flex;align-items:center;justify-content:space-between;width:100%;max-width:440px;background:#0d1016;border:1px solid #232736;border-radius:18px;padding:10px 14px}
.mpl{display:flex;align-items:center;gap:10px}.mav{position:relative;width:46px;height:46px;border-radius:50%;background:#1b1f2c;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px}
.mbd{position:absolute;right:-4px;bottom:-4px;width:20px;height:20px;border-radius:50%;font-size:11px;display:flex;align-items:center;justify-content:center;color:#fff}.mbd.r{background:#e5484d}.mbd.b{background:#2f7bff}
.mnm b{display:block;font-size:16px}.mnm small{color:#9aa3b8}.mvs{color:#566;font-weight:700}
.mscroll{width:100%;max-width:440px;height:min(62vh,520px);overflow:auto;background:#0f1420;border:1px solid #232736;border-radius:20px}
.m2c{width:48px;height:48px;border:0;border-right:1px solid #1c2435;border-bottom:1px solid #1c2435;background:transparent;padding:6px;position:relative}.m2c svg{width:100%;height:100%}.m2c.x{color:#2f7bff}.m2c.o{color:#ff4a4a}.m2c.win{background:rgba(46,224,106,.18);color:#2ee06a;box-shadow:inset 0 0 0 1px #2ee06a}.m2c.last::after{content:"";position:absolute;right:6px;top:6px;width:6px;height:6px;border-radius:50%;background:#f5c542}
.mhint{color:#667;font-size:13px}

.gb{flex:1;overflow:auto;padding:8px 14px 20px;display:flex;flex-direction:column;align-items:center;gap:10px}
.gres{position:absolute;inset:0;background:rgba(0,0,0,.7);display:flex;align-items:center;justify-content:center}.gbox{background:#12141c;border:1px solid #f5c542;border-radius:22px;padding:24px;text-align:center;width:min(320px,86%)}
.gbtn{display:block;width:100%;margin-top:10px;padding:12px;border:0;border-radius:14px;background:#f5c542;color:#111;font:600 16px Poppins,sans-serif}.gbtn.g2{background:#2a2f40;color:#fff}
.dbar{display:flex;gap:10px;width:100%;max-width:440px;align-items:center;justify-content:space-between;background:#0d1016;border-radius:18px;padding:10px 14px}
.dbar button{border:0;border-radius:12px;padding:10px 16px;background:#4a5366;color:#fff;font:600 15px Poppins,sans-serif}.dbar button:disabled{opacity:.4}.dbar .pl{background:#12351f;border:1px solid #2c6b43}
.dbd{width:100%;max-width:440px;min-height:210px;border:3px solid #5b3d16;border-radius:20px;background:#17582f;padding:10px;display:flex;flex-wrap:wrap;gap:3px;align-content:flex-start;justify-content:center}
.dend{display:flex;justify-content:space-between;width:100%;max-width:440px;font-size:13px;color:#cfe}
.dhand{display:flex;gap:6px;flex-wrap:wrap;justify-content:center;width:100%;max-width:440px;background:#0e3a1f;border-radius:20px;padding:12px;min-height:110px}
.dt{display:flex;background:#f4efe0;border-radius:6px;box-shadow:0 2px 0 #b9b19a;flex:none}.dt.h{width:56px;height:28px}.dt.v{flex-direction:column;width:40px;height:80px}
.dh{flex:1;display:grid;grid-template:repeat(3,1fr)/repeat(3,1fr);padding:2px}.dh i{width:5px;height:5px;border-radius:50%;background:#111;place-self:center}
.dt.h .dh+.dh{border-left:1px solid #aaa}.dt.v .dh+.dh{border-top:1px solid #aaa}.dhand .dt{opacity:.45}.dhand .dt.ok{opacity:1;outline:3px solid #f5c542;cursor:pointer}
.mgrid,.cgrid{display:grid;width:100%;max-width:420px;aspect-ratio:1;gap:2px;background:#0a2f18;padding:3px;border-radius:12px}
.mc{border:0;background:#1d6b3a;border-radius:4px;font:700 18px Poppins;padding:0}.mc.x{color:#4aa3ff}.mc.o{color:#ff9a1f}
.cgrid{grid-template-columns:repeat(8,1fr)}.cs{border:0;border-radius:0;position:relative;display:flex;align-items:center;justify-content:center;font-size:30px;padding:0}.cs.l{background:#e9d9b4}.cs.d{background:#8a5a2b}.cs.sel{outline:3px solid #f5c542;outline-offset:-3px}.cs.to::after{content:"";position:absolute;width:30%;height:30%;border-radius:50%;background:rgba(245,197,66,.85)}
.pc{width:76%;height:76%;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700}.pc.w{background:#fff;color:#111;box-shadow:0 2px 0 #aaa}.pc.k{background:#c0262d;color:#fff;box-shadow:0 2px 0 #6e1014}
.ch.w{color:#fff;text-shadow:0 0 2px #000,0 0 2px #000}.ch.b{color:#111}
.lbd{position:relative;width:300px;height:300px;border-radius:50%;background:#14502a;border:3px solid #5b3d16;flex:none}
.ld{position:absolute;width:12px;height:12px;border-radius:50%;background:rgba(255,255,255,.25);margin:-6px 0 0 -6px}.ld.s{background:#f5c542}
.lp{position:absolute;width:24px;height:24px;margin:-12px 0 0 -12px;border-radius:50%;border:2px solid #fff;padding:0}.lp.a{background:#2f7bff}.lp.b{background:#ff9a1f}.lp.m{box-shadow:0 0 0 4px #f5c542}
.ltr{display:flex;gap:8px;align-items:center;min-height:34px}.ltr .lp{position:static;margin:0}.ldie{border:0;border-radius:14px;padding:12px 22px;background:#f5c542;color:#111;font:700 17px Poppins}
`;document.head.append(css);
let CFG={games:{}};
function paint(){document.querySelectorAll("#pg-games [data-g]").forEach(b=>{const c=(CFG.games||{})[b.dataset.g],s=b.querySelector("small");if(!c||!s)return;if(!s.dataset.o)s.dataset.o=s.textContent;s.textContent=s.dataset.o+" · Miz "+c.min+"–"+c.max+" HTG"})}
fetch("/api/config").then(r=>r.json()).then(c=>{CFG=c;paint()}).catch(()=>{});

/* ---------- DOMINO ---------- */
const PP=[[],[4],[0,8],[0,4,8],[0,2,6,8],[0,2,4,6,8],[0,2,3,5,6,8]];
const half=n=>{const h=E("div","dh");for(let i=0;i<9;i++){const p=E("i");if(!PP[n].includes(i))p.style.visibility="hidden";h.append(p)}return h};
const tile=(a,b,o)=>{const t=E("div","dt "+o);t.append(half(a),half(b));return t};
function dom(b,st,done){
 const T=[];for(let i=0;i<7;i++)for(let j=i;j<7;j++)T.push([i,j]);sh(T);
 const me=T.splice(0,7),bot=T.splice(0,7),pile=T,ch=[],plack=new Set();let turn,passes=0,over=false;
 const sum=h=>h.reduce((s,t)=>s+t[0]+t[1],0),ends=()=>ch.length?[ch[0].l,ch[ch.length-1].r]:null;
 const fits=(t,s)=>{const e=ends();return t[0]===e[s]||t[1]===e[s]},mvs=h=>h.filter(t=>fits(t,0)||fits(t,1));
 const place=(t,s)=>{if(!ch.length){ch.push({l:t[0],r:t[1]});return}const e=ends();if(s===0)ch.unshift(t[1]===e[0]?{l:t[0],r:t[1]}:{l:t[1],r:t[0]});else ch.push(t[0]===e[1]?{l:t[0],r:t[1]}:{l:t[1],r:t[0]})};
 let f=null;[[me,0],[bot,1]].forEach(([h,w])=>h.forEach(t=>{const k=(t[0]===t[1]?100:0)+t[0]+t[1];if(!f||k>f.k)f={t,k,w,h}}));
 f.h.splice(f.h.indexOf(f.t),1);place(f.t,0);turn=f.w?0:1;
 const bar=E("div","dbar"),info=E("div"),pileB=E("button","pl"),passB=E("button",0,"Pase"),ep=E("div","dend"),brd=E("div","dbd"),hand=E("div","dhand"),ch2=E("div");
 bar.append(info,pileB,passB);b.append(bar,ep,brd,hand,ch2);
 function render(){const e=ends(),can=turn===0&&!over,m=mvs(me);info.textContent="KataRenn · "+bot.length+" domino";pileB.textContent="Pil "+pile.length;
  ep.textContent="";ep.append(E("span",0,"Bout goch: "+e[0]),E("span",0,"Bout dwat: "+e[1]));
  brd.textContent="";ch.forEach(c=>brd.append(tile(c.l,c.r,"h")));hand.textContent="";ch2.textContent="";
  me.forEach(t=>{const el=tile(t[0],t[1],"v");if(can&&(fits(t,0)||fits(t,1)))el.classList.add("ok");el.onclick=()=>pick(t);hand.append(el)});
  pileB.disabled=!(can&&!m.length&&pile.length);passB.disabled=!(can&&!m.length&&!pile.length);
  st(over?"":turn?"KataRenn ap reflechi...":m.length?"Se tou pa w!":pile.length?"Pa gen domino pou jwe — tape sou Pil la.":"Pa gen domino — peze Pase.")}
 function play(h,t,s,w){h.splice(h.indexOf(t),1);place(t,s);passes=0;if(!h.length){over=true;render();return done(w?"lose":"win")}turn=1-turn;render();if(turn)setTimeout(botMove,900)}
 function block(){over=true;render();const a=sum(me),c=sum(bot);done(a<c?"win":a>c?"lose":"draw")}
 function pick(t){if(turn||over)return;const l=fits(t,0),r=fits(t,1);if(!l&&!r)return;
  if(l&&r&&ends()[0]!==ends()[1]){ch2.textContent="";const x=E("button","gbtn","Bò goch"),y=E("button","gbtn","Bò dwat");x.onclick=()=>play(me,t,0,0);y.onclick=()=>play(me,t,1,0);ch2.append(x,y)}else play(me,t,l?0:1,0)}
 pileB.onclick=()=>{const e=ends();e.forEach(v=>plack.add(v));me.push(pile.pop());render()};
 passB.onclick=()=>{ends().forEach(v=>plack.add(v));if(++passes>=2)return block();turn=1;render();setTimeout(botMove,900)};
 function botMove(){if(over)return;let m;for(;;){m=mvs(bot);if(m.length||!pile.length)break;bot.push(pile.pop())}
  if(!m.length){if(++passes>=2)return block();turn=0;render();return}
  let best=null,bv=-1e9;m.forEach(t=>[0,1].forEach(s=>{if(!fits(t,s))return;const e=ends(),o=e[s],nv=t[0]===o?t[1]:t[0],ne=s?[e[0],nv]:[nv,e[1]],rest=bot.filter(x=>x!==t);
   let v=t[0]+t[1]+(t[0]===t[1]?4:0)+rest.filter(x=>ne.some(n=>x[0]===n||x[1]===n)).length*2+Math.random();ne.forEach(n=>{if(plack.has(n))v+=7});if(v>bv){bv=v;best=[t,s]}}));
  play(bot,best[0],best[1],1)}
 render();if(turn)setTimeout(botMove,900)}

/* ---------- MORPION (5 an ranje) ---------- */
function mor(b,st,done){
 const N=15,g=Array(N*N).fill(0),D=[[1,0],[0,1],[1,1],[1,-1]];let over=false,turn=0,last=-1;
 if(b.parentNode)b.parentNode.style.background="#07080d";
 const X='<svg viewBox="0 0 40 40"><path d="M9 9L31 31M31 9L9 31" stroke="currentColor" stroke-width="5" stroke-linecap="round" fill="none"/></svg>',O='<svg viewBox="0 0 40 40"><circle cx="20" cy="20" r="12" stroke="currentColor" stroke-width="5" fill="none"/></svg>';
 const mkP=(name,badge,cls)=>{const d=E("div","mpl"),av=E("div","mav",name[0]),bg=E("span","mbd "+cls,badge),nm=E("div","mnm"),pt=E("small",0,"0 pt");av.append(bg);nm.append(E("b",0,name),pt);d.append(av,nm);return[d,pt]};
 const[pb,ptb]=mkP("KataRenn","O","r"),[pm,ptm]=mkP("Ou menm","X","b"),card=E("div","mcard");card.append(pb,E("span","mvs","VS"),pm);
 const sc=E("div","mscroll"),grid=E("div");grid.style.cssText="display:grid;grid-template-columns:repeat("+N+",48px);width:"+N*48+"px";sc.append(grid);
 b.append(card,sc,E("div","mhint","← Glise pou wè tout tablo a →"));
 const cells=g.map((_,i)=>{const c=E("button","m2c");c.onclick=()=>mv(i,1);grid.append(c);return c});
 setTimeout(()=>{sc.scrollLeft=(sc.scrollWidth-sc.clientWidth)/2;sc.scrollTop=(sc.scrollHeight-sc.clientHeight)/2},0);
 const ok=(x,y)=>x>=0&&x<N&&y>=0&&y<N;
 const run=(i,d,w)=>{const r=Math.floor(i/N),c=i%N;let n=1,open=0;for(const s of[1,-1]){let x=r+d[0]*s,y=c+d[1]*s;while(ok(x,y)&&g[x*N+y]===w){n++;x+=d[0]*s;y+=d[1]*s}if(ok(x,y)&&g[x*N+y]===0)open++}return[n,open]};
 const line=(i,d,w)=>{const r=Math.floor(i/N),c=i%N,o=[i];for(const s of[1,-1]){let x=r+d[0]*s,y=c+d[1]*s;while(ok(x,y)&&g[x*N+y]===w){o.push(x*N+y);x+=d[0]*s;y+=d[1]*s}}return o};
 const val=(i,w)=>{let s=0;for(const d of D){const[n,o]=run(i,d,w);if(n>=5)s+=1e6;else if(o)s+=[0,2,20,200,5000][n]*(o===2?2:1)}return s};
 const best=w=>{let m=0;g.forEach((v,i)=>{if(v===w)for(const d of D)m=Math.max(m,run(i,d,w)[0])});return m};
 const upd=()=>{ptm.textContent=best(1)*2+" pt";ptb.textContent=best(-1)*2+" pt"};
 function mv(i,w){if(over||g[i]||(w===1&&turn))return;g[i]=w;if(last>=0)cells[last].classList.remove("last");last=i;cells[i].innerHTML=w===1?X:O;cells[i].className="m2c "+(w===1?"x":"o")+" last";upd();
  const d=D.find(d=>run(i,d,w)[0]>=5);if(d){over=true;line(i,d,w).forEach(j=>cells[j].classList.add("win"));st(w===1?"Ou genyen!":"KataRenn genyen!");return done(w===1?"win":"lose")}
  if(!g.includes(0)){over=true;return done("draw")}
  turn=w===1?1:0;st(turn?"KataRenn ap jwe...":"👆 Se tou pa w — poze yon pyon!");if(turn)setTimeout(bot,500)}
 function bot(){let bs=-1,bi=-1;const any=g.some(Boolean),near=i=>{const r=Math.floor(i/N),c=i%N;for(let x=-2;x<=2;x++)for(let y=-2;y<=2;y++)if(ok(r+x,c+y)&&g[(r+x)*N+c+y])return true;return false};
  g.forEach((v,i)=>{if(v||(any&&!near(i)))return;const s=val(i,-1)*1.1+val(i,1)+Math.random();if(s>bs){bs=s;bi=i}});mv(bi<0?g.indexOf(0):bi,-1)}
 st("👆 Se tou pa w — poze yon pyon!")}

/* ---------- DAME ---------- */
function dam(b,st,done){
 let B=Array(64).fill(0);for(let i=0;i<64;i++){const r=i>>3,c=i&7;if((r+c)%2){if(r<3)B[i]=-1;else if(r>4)B[i]=1}}
 const ins=(r,c)=>r>=0&&r<8&&c>=0&&c<8,dirs=p=>Math.abs(p)===2?[[1,1],[1,-1],[-1,1],[-1,-1]]:p>0?[[-1,1],[-1,-1]]:[[1,1],[1,-1]];
 function gen(bd,s){const out=[],jumps=[];for(let i=0;i<64;i++){const p=bd[i];if(p*s<=0)continue;
  const walk=(pos,caps)=>{let any=false;const r=pos>>3,c=pos&7;
   for(const[dr,dc]of dirs(p)){const m=(r+dr)*8+c+dc,l=(r+2*dr)*8+c+2*dc;
    if(ins(r+2*dr,c+2*dc)&&bd[m]*s<0&&!caps.includes(m)&&(bd[l]===0||l===i)){any=true;const nc=[...caps,m],pr=Math.abs(p)===1&&((s>0&&r+2*dr===0)||(s<0&&r+2*dr===7));if(pr)jumps.push({f:i,t:l,c:nc});else walk(l,nc)}}
   if(!any&&caps.length)jumps.push({f:i,t:pos,c:caps})};
  walk(i,[]);const r=i>>3,c=i&7;for(const[dr,dc]of dirs(p)){const t=(r+dr)*8+c+dc;if(ins(r+dr,c+dc)&&bd[t]===0)out.push({f:i,t,c:[]})}}
  return jumps.length?jumps:out}
 const app=(bd,m)=>{const n=bd.slice(),p=n[m.f];n[m.f]=0;m.c.forEach(x=>n[x]=0);const r=m.t>>3;n[m.t]=p===1&&r===0?2:p===-1&&r===7?-2:p;return n};
 const ev=bd=>{let s=0;for(let i=0;i<64;i++){const p=bd[i];if(!p)continue;const r=i>>3,v=Math.abs(p)===2?170:100+(p>0?7-r:r)*4;s+=p>0?-v:v}return s};
 function mm(bd,s,d,al,be){const ms=gen(bd,s);if(!ms.length)return s===-1?-1e5-d:1e5+d;if(!d)return ev(bd);
  if(s===-1){let v=-1e9;for(const m of ms){v=Math.max(v,mm(app(bd,m),1,d-1,al,be));al=Math.max(al,v);if(al>=be)break}return v}
  let v=1e9;for(const m of ms){v=Math.min(v,mm(app(bd,m),-1,d-1,al,be));be=Math.min(be,v);if(al>=be)break}return v}
 const grid=E("div","cgrid");b.append(grid);let sel=-1,over=false,turn=0;
 function render(){grid.textContent="";const ms=gen(B,1),dest=sel>=0?ms.filter(m=>m.f===sel).map(m=>m.t):[],mov=new Set(ms.map(m=>m.f));
  for(let i=0;i<64;i++){const r=i>>3,c=i&7,x=E("button","cs "+((r+c)%2?"d":"l")),p=B[i];if(i===sel)x.classList.add("sel");if(dest.includes(i))x.classList.add("to");
   if(p){const pc=E("div","pc "+(p>0?"w":"k"),Math.abs(p)===2?"K":"");x.append(pc)}
   x.onclick=()=>{if(over||turn)return;if(dest.includes(i)){const m=ms.find(m=>m.f===sel&&m.t===i);B=app(B,m);sel=-1;turn=1;render();if(!gen(B,-1).length){over=true;return done("win")}st("KataRenn ap reflechi...");setTimeout(bot,400)}else if(mov.has(i)){sel=i;render()}};grid.append(x)}
  if(!over&&!turn)st(ms.some(m=>m.c.length)?"Ou dwe manje!":"Se tou pa w!")}
 function bot(){const ms=gen(B,-1);let bm=ms[0],bv=-1e9;ms.forEach(m=>{const v=mm(app(B,m),1,5,-1e9,1e9)+Math.random();if(v>bv){bv=v;bm=m}});B=app(B,bm);turn=0;render();if(!gen(B,1).length){over=true;done("lose")}}
 render()}

/* ---------- ECHÈK ---------- */
function che(b,st,done){
 let B=("rnbqkbnrpppppppp"+" ".repeat(32)+"PPPPPPPPRNBQKBNR").split("");let ply=0;
 const col=p=>p===" "?0:p===p.toUpperCase()?1:-1,V={p:100,n:320,b:330,r:500,q:900,k:0};
 function gen(bd,s){const o=[];for(let i=0;i<64;i++){const p=bd[i];if(col(p)!==s)continue;const r=i>>3,c=i&7,t=p.toLowerCase();
  const add=(x,y,cap)=>{if(x<0||x>7||y<0||y>7)return false;const q=bd[x*8+y];if(q!==" "&&col(q)===s)return false;if(cap===1&&q===" ")return false;if(cap===2&&q!==" ")return false;o.push([i,x*8+y]);return q===" "};
  if(t==="p"){const dd=-s,h=s>0?6:1;add(r+dd,c,2)&&r===h&&add(r+2*dd,c,2);add(r+dd,c-1,1);add(r+dd,c+1,1)}
  else if(t==="n")[[1,2],[2,1],[-1,2],[-2,1],[1,-2],[2,-1],[-1,-2],[-2,-1]].forEach(([x,y])=>add(r+x,c+y,0));
  else if(t==="k"){for(let x=-1;x<2;x++)for(let y=-1;y<2;y++)if(x||y)add(r+x,c+y,0)}
  else{const ds=[];if(t!=="b")ds.push([1,0],[-1,0],[0,1],[0,-1]);if(t!=="r")ds.push([1,1],[1,-1],[-1,1],[-1,-1]);for(const[x,y]of ds){let a=r+x,e=c+y;while(add(a,e,0)){a+=x;e+=y}}}}
  return o}
 const mk=(bd,m)=>{const n=bd.slice(),p=n[m[0]];n[m[1]]=p;n[m[0]]=" ";if(p==="P"&&m[1]<8)n[m[1]]="Q";if(p==="p"&&m[1]>55)n[m[1]]="q";return n};
 const inChk=(bd,s)=>{const ki=bd.indexOf(s>0?"K":"k");return ki<0||gen(bd,-s).some(m=>m[1]===ki)},legal=(bd,s)=>gen(bd,s).filter(m=>!inChk(mk(bd,m),s));
 const ev=bd=>{let s=0;for(let i=0;i<64;i++){const p=bd[i];if(p===" ")continue;const t=p.toLowerCase();let v=V[t];if(t!=="k"&&t!=="r")v+=(4-Math.abs(3.5-(i&7))-Math.abs(3.5-(i>>3)))*5;if(t==="p")v+=(p==="P"?6-(i>>3):(i>>3)-1)*6;s+=col(p)*v}return s};
 function ab(bd,s,d,al,be){if(!d)return s*ev(bd);const ms=gen(bd,s).sort((x,y)=>(bd[y[1]]!==" ")-(bd[x[1]]!==" "));let best=-1e9;
  for(const m of ms){if(bd[m[1]].toLowerCase()==="k")return 1e5+d;const v=-ab(mk(bd,m),-s,d-1,-be,-al);if(v>best)best=v;if(v>al)al=v;if(al>=be)break}return best===-1e9?0:best}
 const G={k:"♚",q:"♛",r:"♜",b:"♝",n:"♞",p:"♟"},grid=E("div","cgrid");b.append(grid);let sel=-1,over=false,turn=0;
 function render(){grid.textContent="";const ms=legal(B,1),dest=sel>=0?ms.filter(m=>m[0]===sel).map(m=>m[1]):[];
  for(let i=0;i<64;i++){const r=i>>3,c=i&7,p=B[i],x=E("button","cs "+((r+c)%2?"d":"l"));if(i===sel)x.classList.add("sel");if(dest.includes(i))x.classList.add("to");
   if(p!==" ")x.append(E("span","ch "+(col(p)>0?"w":"b"),G[p.toLowerCase()]));
   x.onclick=()=>{if(over||turn)return;if(dest.includes(i)){B=mk(B,[sel,i]);sel=-1;ply++;fin(-1)||(turn=1,render(),st("KataRenn ap reflechi..."),setTimeout(bot,300))}else if(col(p)===1){sel=i;render()}};grid.append(x)}
  if(!over&&!turn)st(inChk(B,1)?"Wa ou an echèk!":"Se tou pa w (ou jwe blan)")}
 function fin(s){const l=legal(B,s);if(l.length&&ply<160)return false;over=true;render();done(l.length?"draw":inChk(B,s)?(s===-1?"win":"lose"):"draw");return true}
 function bot(){const ms=legal(B,-1);let bm=ms[0],bv=-1e9;ms.forEach(m=>{const v=-ab(mk(B,m),1,2,-1e9,1e9)+Math.random()*3;if(v>bv){bv=v;bm=m}});B=mk(B,bm);ply++;turn=0;if(!fin(1))render()}
 render()}

/* ---------- LUDO ---------- */
function lud(b,st,done){
 const P=[[-1,-1,-1,-1],[-1,-1,-1,-1]],S=300;let turn=0,die=0,six=0,over=false,busy=false,movable=[];
 const t1=E("div","ltr"),box=E("div","lbd"),t0=E("div","ltr"),dieB=E("button","ldie","Voye dé");b.append(t1,box,t0,dieB);
 const cell=(w,p)=>(p+w*20)%40,xy=(w,p)=>{let a=(w*20)/40*2*Math.PI+Math.PI/2,r=S*.42;if(p<40){a=cell(w,p)/40*2*Math.PI+Math.PI/2}else r=S*.42*(1-(p-39)*.17);return[S/2+r*Math.cos(a),S/2+r*Math.sin(a)]};
 const ok=(w,k,d)=>{const p=P[w][k];return p===-1?d===6:p+d<=44};
 const thr=(w,c)=>P[1-w].some(q=>q>=0&&q<40&&((c-cell(1-w,q)+40)%40)>0&&((c-cell(1-w,q)+40)%40)<=6);
 function sc(w,k,d){const p=P[w][k],np=p===-1?0:p+d;let v=np;if(p===-1)v+=40;if(np===44)v+=80;else if(np>=40)v+=30;
  if(np<40){const c=cell(w,np);if(c%20&&P[1-w].some(q=>q>=0&&q<40&&cell(1-w,q)===c))v+=120;if(c%20&&thr(w,c))v-=50}
  if(p>=0&&p<40&&cell(w,p)%20&&thr(w,cell(w,p)))v+=35;return v}
 function render(){box.textContent="";t0.textContent="";t1.textContent="";
  for(let i=0;i<40;i++){const[x,y]=xy(0,i),d=E("div","ld"+(i%20?"":" s"));d.style.left=x+"px";d.style.top=y+"px";box.append(d)}
  [0,1].forEach(w=>{let fin=0;P[w].forEach((p,k)=>{if(p===44){fin++;return}const el=E("button","lp "+(w?"b":"a")),can=!w&&movable.includes(k);if(can){el.classList.add("m");el.onclick=()=>go(k)}
   if(p===-1){(w?t1:t0).append(el)}else{const[x,y]=xy(w,p);el.style.left=x+"px";el.style.top=y+"px";box.append(el)}});
   (w?t1:t0).append(E("small",0,(w?"KataRenn":"Ou")+" · rive: "+fin+"/4"))})}
 function mvp(w,k,d){const p=P[w][k],np=p===-1?0:p+d;P[w][k]=np;if(np<40){const c=cell(w,np);if(c%20)P[1-w]=P[1-w].map(q=>q>=0&&q<40&&cell(1-w,q)===c?-1:q)}}
 function go(k){movable=[];mvp(turn,k,die);if(P[turn].every(q=>q===44)){over=true;render();return done(turn?"lose":"win")}next(die===6)}
 function next(again){if(again&&six<2)six++;else{six=0;turn=1-turn}movable=[];busy=false;render();if(turn)setTimeout(roll,700);else st("Se tou pa w — voye dé a.")}
 function roll(){if(over)return;busy=true;die=1+R(6);dieB.textContent="Dé: "+die;movable=P[turn].map((_,k)=>k).filter(k=>ok(turn,k,die));render();
  if(!movable.length){st((turn?"KataRenn":"Ou")+" pa ka deplase ak "+die+".");return setTimeout(()=>next(false),900)}
  if(turn)setTimeout(()=>{let bk=movable[0],bv=-1e9;movable.forEach(k=>{const v=sc(1,k,die);if(v>bv){bv=v;bk=k}});go(bk)},900);else st("Tape sou yon pyon ki limen pou deplase l.")}
 dieB.onclick=()=>{if(!turn&&!busy&&!over)roll()};render();st("Se tou pa w — voye dé a. (6 = soti yon pyon)")}

const GAMES={Domino:dom,Morpion:mor,Dame:dam,"Echèk":che,Ludo:lud};
function askBet(name){return new Promise(res=>{const cf=(CFG.games||{})[name]||{min:10,max:5000},m=CFG.gameMult||2;
 const ov=E("div","gres"),bx=E("div","gbox"),inp=E("input"),inf=E("div",0,""),go=E("button","gbtn","Kòmanse"),no=E("button","gbtn g2","Anile");
 inp.type="number";inp.inputMode="numeric";inp.value=cf.min;inp.style.cssText="width:100%;padding:12px;border-radius:12px;border:1px solid #2a2f40;background:#0d1016;color:#fff;font:600 20px Poppins,sans-serif;text-align:center;margin:8px 0";inf.style.color="#f5c542";
 const upd=()=>{const v=Math.floor(+inp.value);inf.textContent=v>0?"Si w genyen: "+v*m+" HTG ("+m+"x miz la)":""};inp.oninput=upd;upd();
 bx.append(E("h2",0,name),E("p",0,"Konbyen w vle mize? ("+cf.min+" – "+cf.max+" HTG)"),inp,inf,go,no);ov.style.position="fixed";ov.style.zIndex=1000;ov.append(bx);document.body.append(ov);
 go.onclick=()=>{const v=Math.floor(+inp.value);if(!(v>=cf.min&&v<=cf.max))return toast("Miz la dwe ant "+cf.min+" ak "+cf.max+" HTG.");ov.remove();res(v)};no.onclick=()=>{ov.remove();res(null)}})}
async function open(name){
 if(typeof U==="undefined"||!U)return;if(!U.act)return toast("Aktive kont ou pou w ka jwe.");
 let gid=null,bet=0;
 if(SRV){bet=await askBet(name);if(!bet)return;try{gid=(await api("game/start",{body:{game:name,bet}})).id;pull()}catch(e){return toast(e.message)}}
 const o=E("div","gmo"),h=E("header"),bk=E("button","gbk","←"),tt=E("div","gt"),stl=E("div","gstat"),bd=E("div","gb");
 tt.append(E("b",0,name),E("small",0,bet?"Miz "+bet+" HTG · Genyen "+bet*(CFG.gameMult||2)+" HTG":""));h.append(bk,tt);o.append(h,stl,bd);document.body.append(o);
 const st=t=>stl.textContent=t;let fin=false;const close=()=>{o.remove();tab("games")};
 bk.onclick=()=>{if(fin||confirm("Si w kite, ou pèdi miz la. Kite?")){if(!fin&&gid)api("game/end",{body:{id:gid,result:"lose"}}).then(pull).catch(()=>{});fin=true;close()}};
 const done=async res=>{if(fin)return;fin=true;let m=res==="win"?"Ou genyen!":res==="lose"?"Ou pèdi.":"Egalite.";
  if(gid){try{const r=await api("game/end",{body:{id:gid,result:res}});if(r.paid)m+=" +"+r.paid+" HTG";pull()}catch(e){m+=" ("+e.message+")"}}
  const ov=E("div","gres"),bx=E("div","gbox"),a=E("button","gbtn","Rejwe"),c=E("button","gbtn g2","Fèmen");bx.append(E("h2",0,m),a,c);ov.append(bx);o.append(ov);a.onclick=()=>{o.remove();open(name)};c.onclick=close};
 GAMES[name](bd,st,done)}
document.querySelector("#pg-games").addEventListener("click",e=>{const b=e.target.closest("[data-g]");if(!b||!GAMES[b.dataset.g])return;e.stopImmediatePropagation();e.stopPropagation();open(b.dataset.g)},true);
})();
